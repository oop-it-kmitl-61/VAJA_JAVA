package com.vaja.screen.transition;

public interface Action {

    public void action();
}
