package com.vaja.game.battle.ai;


import com.vaja.game.model.Monster;

public class Brain {
    private Monster monster;

    public Brain(Monster owner){

    }
}
