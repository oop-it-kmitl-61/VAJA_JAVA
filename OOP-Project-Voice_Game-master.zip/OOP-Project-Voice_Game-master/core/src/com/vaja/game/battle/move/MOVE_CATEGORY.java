package com.vaja.game.battle.move;

public enum MOVE_CATEGORY {
    PHYSICAL,
    SPECIAL,
    ;
}
