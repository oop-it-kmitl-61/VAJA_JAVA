package com.vaja.game.battle.move;

public enum MOVE_TYPE {
    NORMAL,
    GRASS,
    FIRE,
    WATER,
    ELECTRIC,
    ROCK,
    STEEL,
    DARK,
    DRAGON,
    ;
}
