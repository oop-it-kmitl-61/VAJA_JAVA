package com.vaja.game;

public class Setting {

    public static int TILE_SIZE = 16;
    public static float SCALE = 2f;
    public static float SCALE_TILE_S = TILE_SIZE * SCALE;

    public static float SCALE_UI = 2f;
}
