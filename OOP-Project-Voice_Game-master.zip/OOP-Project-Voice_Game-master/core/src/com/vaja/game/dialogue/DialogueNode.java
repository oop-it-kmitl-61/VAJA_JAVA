package com.vaja.game.dialogue;

import java.util.List;

public interface DialogueNode {
    public int getID();

    public List<Integer> getPointers();
}
