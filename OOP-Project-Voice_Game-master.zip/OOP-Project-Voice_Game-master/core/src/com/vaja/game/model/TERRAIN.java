package com.vaja.game.model;

public enum TERRAIN {

    GRASS1,
    GRASS2,
    DIRTUP1,
    DIRTUP2,
    DIRTUP3,
    DIRTMID1,
    DIRTMID2,
    DIRTMID3,
    DIRTDOWN1,
    DIRTDOWN2,
    DIRTDOWN3
    ;

}
