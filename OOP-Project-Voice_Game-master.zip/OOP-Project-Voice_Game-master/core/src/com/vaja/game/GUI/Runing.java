package com.vaja.game.GUI;

import com.vaja.game.MainGame;


public class Runing {

	
	public static void main(String[] args) {
		MainGame obj = new MainGame();
    	obj.RunGame();
//         this.dispose();    
	}
}
